package io.github.bibekshakya35.simplenoteapp.listener;

import android.view.View;

public interface OnRecyclerViewItemClickListener {
    void onItemClick(View parentView, View childView, int position);
}
