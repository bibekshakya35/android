package io.github.bibekshakya35.simplenoteapp.listener;

import android.view.View;

public interface OnItemClickListener {
    void onItemClick(View view, int position);
}
