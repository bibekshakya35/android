package io.github.bibekshakya35.simplenoteapp;

import android.app.Application;

public class AppController extends Application {


}
