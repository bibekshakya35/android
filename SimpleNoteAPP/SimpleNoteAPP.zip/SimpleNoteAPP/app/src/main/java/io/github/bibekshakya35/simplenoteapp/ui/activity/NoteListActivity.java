package io.github.bibekshakya35.simplenoteapp.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import io.github.bibekshakya35.simplenoteapp.AppConstants;
import io.github.bibekshakya35.simplenoteapp.R;
import io.github.bibekshakya35.simplenoteapp.listener.OnRecyclerViewItemClickListener;
import io.github.bibekshakya35.simplenoteapp.model.Note;
import io.github.bibekshakya35.simplenoteapp.repository.NoteRepository;
import io.github.bibekshakya35.simplenoteapp.ui.adapter.NotesListAdapter;
import io.github.bibekshakya35.simplenoteapp.util.NavigatorUtils;
import io.github.bibekshakya35.simplenoteapp.util.RecyclerItemClickListener;

public class NoteListActivity extends AppCompatActivity implements View.OnClickListener, OnRecyclerViewItemClickListener, AppConstants {
    private TextView emptyView;
    private RecyclerView recyclerView;
    private NotesListAdapter notesListAdapter;
    private FloatingActionButton floatingActionButton;

    private NoteRepository noteRepository;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_list);
        this.noteRepository = new NoteRepository(getApplicationContext());

        recyclerView = findViewById(R.id.task_list);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this, this));

        floatingActionButton = findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(this);

        emptyView = findViewById(R.id.empty_view);

        updateTaskList();
    }

    private void updateTaskList() {
        noteRepository.getTasks().observe(this, (notes) -> {
            if (!notes.isEmpty()) {
                emptyView.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                if (notesListAdapter == null) {
                    notesListAdapter = new NotesListAdapter(notes);
                    recyclerView.setAdapter(notesListAdapter);
                } else {
                    notesListAdapter.addTasks(notes);
                }
            } else updateEmptyView();
        });
    }

    private void updateEmptyView() {
        emptyView.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(NoteListActivity.this, AddNoteActivity.class);
        startActivityForResult(intent, ACTIVITY_REQUEST_CODE);
    }

    @Override
    public void onItemClick(View parentView, View childView, int position) {
        Note note = notesListAdapter.getItem(position);
        if (note.isEncrypt()) {
            NavigatorUtils.redirectToPwdScreen(this, note);

        } else {
            NavigatorUtils.redirectToEditTaskScreen(this, note);
        }
    }
}

