package io.github.bibekshakya35.simplenoteapp.db;


import androidx.room.Database;
import androidx.room.RoomDatabase;

import io.github.bibekshakya35.simplenoteapp.dao.DaoAccess;
import io.github.bibekshakya35.simplenoteapp.model.Note;


@Database(entities = {Note.class}, version = 1, exportSchema = false)
public abstract class NoteDatabase extends RoomDatabase {
    public abstract DaoAccess daoAccess();
}
